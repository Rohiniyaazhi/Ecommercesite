

package contruct;


public class Movie{
    
        int no;
        String name;
        int cost;
        int date;
        char grade;
        public static void main(String args[]){
movie2 m1=new movie2(4,"rohini",'A');
movie2 m2=new movie2(6,"raji",'C');
m1.display();
m2.display();
}


}
class movie2
  {
    int no;
  String name;
  char grade;
movie2(int n,String s){
            no=n;
         name=s;
   }
movie2(int n,String s,char g){
    no=n;
    name=s;
    grade=g;
}
void display(){
System.out.println(no+" "+name+grade);
}

}