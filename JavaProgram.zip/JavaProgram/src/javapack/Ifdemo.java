
package javapack;


public class Ifdemo {

    
    public static void main(String[] args) {
        int a = 11;
         int b = 2;
         if ( a % b == 0 )
         {
               System.out.println(a + " is divisible by "+ b);
         }
         else
         {
               System.out.println(a + " is not divisible by " + b);
         }

    }
    
}
