/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javapack;

/**
 *
 * @author MRuser
 */
public class IfelseDemo {
    public static void main(String[] args) {

        int testscore = 76;
        char grade;

        if (testscore >= 90) {
            grade = 'A';
        } 
       else if (testscore >= 80) {
            grade = 'B';
        } 
       else if (testscore >= 70) {
            grade = 'C';
        } 
       else if (testscore >= 60) {
            grade = 'D';
        } 
      else {
            grade = 'F';
        }
        System.out.println("Grade = " + grade);
    }

}
