/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package packro;

/**
 *
 * @author MRuser
 */
public class Bike {
    int weight;
    String name;
 Bike(){
     weight=160;
     name="Hero Honda";
 }
 void display(){
     System.out.println(weight+ " "+name);}
        
public static void main(String args[]){  
Bike b=new Bike();  
Bike b1=new Bike();
b.display();
b1.display();
}  
}  


