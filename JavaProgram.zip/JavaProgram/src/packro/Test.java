/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package packro;


public class Test {
    public static void main(String args[])
{  
  Student3 s1=new Student3();  
  Student3 s2=new Student3();  
    s1.insertRecord(111,"Karan");  
  s2.insertRecord(222,"Aryan");  
    s1.displayInformation();  
  s2.displayInformation();  
  
 }  
}
class Student3{
 int rollno;  
 String name;  
 void insertRecord(int r, String n)
{  //method  
  rollno=r;  
  name=n;  
 }  
 void displayInformation()
{
System.out.println(rollno+" "+name);
}//method  
   
}